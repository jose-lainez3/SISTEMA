import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import type { ViewWillEnter } from '@ionic/angular';
import {
  IonHeader, IonToolbar, IonTitle, IonButtons, IonMenuButton, IonContent,
  IonList, IonItem, IonLabel, IonIcon, IonButton, IonSelect, IonSelectOption,
  IonCard, IonCardContent, IonCardHeader, IonCardTitle, IonInput
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import { documentTextOutline, printOutline, downloadOutline, barChartOutline } from 'ionicons/icons';
import { AlumnosService } from '../../services/alumnos';
import { CursosService, Curso } from '../../services/cursos';
import { InventarioService } from '../../services/inventario';
import { AsistenciaService } from '../../services/asistencia';
import { NotasService } from '../../services/notas';
import { ExportarService } from '../../services/exportar';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.page.html',
  styleUrls: ['./reportes.page.scss'],
  standalone: true,
  imports: [
    CommonModule, FormsModule, IonHeader, IonToolbar, IonTitle, IonButtons, IonMenuButton,
    IonContent, IonList, IonItem, IonLabel, IonIcon, IonButton, IonSelect, IonSelectOption,
    IonCard, IonCardContent, IonCardHeader, IonCardTitle, IonInput
  ]
})
export class ReportesPage implements OnInit, ViewWillEnter {
  private alumnosService = inject(AlumnosService);
  private cursosService = inject(CursosService);
  private inventarioService = inject(InventarioService);
  private asistenciaService = inject(AsistenciaService);
  private notasService = inject(NotasService);
  private exportarService = inject(ExportarService);
  private cdr = inject(ChangeDetectorRef);

  cursos: Curso[] = [];

  // Filtros para asistencia
  cursoAsistencia: number | null = null;
  desde: string = new Date().toISOString().slice(0, 10);
  hasta: string = new Date().toISOString().slice(0, 10);

  // Filtros para notas
  cursoNotas: number | null = null;
  periodoNotas = 'Periodo 1';
  periodos = ['Periodo 1', 'Periodo 2', 'Periodo 3', 'Periodo 4'];

  constructor() {
    addIcons({ documentTextOutline, printOutline, downloadOutline, barChartOutline });
  }

  ngOnInit() { this.cargarCursos(); }
  ionViewWillEnter() { this.cargarCursos(); }

  cargarCursos() {
    this.cursosService.listar().subscribe({
      next: (r) => { if (r.success) { this.cursos = r.data || []; this.cdr.detectChanges(); } },
      error: (e) => console.error(e)
    });
  }

  // --- ALUMNOS ---
  exportarAlumnosExcel() {
    this.alumnosService.listar().subscribe(r => {
      if (!r.success) return;
      const datos = (r.data || []).map(a => ({
        Nombres: a.nombres, Apellidos: a.apellidos, DNI: a.dni || '',
        Teléfono: a.telefono || '', Dirección: a.direccion || ''
      }));
      this.exportarService.exportarExcel(datos, 'alumnos', 'Alumnos');
    });
  }

  imprimirAlumnos() {
    this.alumnosService.listar().subscribe(r => {
      if (!r.success) return;
      const filas = (r.data || []).map(a => [a.nombres, a.apellidos, a.dni || 'N/A', a.telefono || 'N/A']);
      this.exportarService.imprimirPdf(
        'Listado de Alumnos',
        ['Nombres', 'Apellidos', 'DNI', 'Teléfono'],
        filas
      );
    });
  }

  // --- CURSOS ---
  exportarCursosExcel() {
    this.cursosService.listar().subscribe(r => {
      if (!r.success) return;
      const datos = (r.data || []).map(c => ({ Nombre: c.nombre, 'Año Lectivo': c.anio_lectivo }));
      this.exportarService.exportarExcel(datos, 'cursos', 'Cursos');
    });
  }

  imprimirCursos() {
    this.cursosService.listar().subscribe(r => {
      if (!r.success) return;
      const filas = (r.data || []).map(c => [c.nombre, c.anio_lectivo]);
      this.exportarService.imprimirPdf('Listado de Cursos', ['Nombre', 'Año Lectivo'], filas);
    });
  }

  // --- INVENTARIO ---
  exportarInventarioExcel() {
    this.inventarioService.listar().subscribe(r => {
      if (!r.success) return;
      const datos = (r.data || []).map(i => ({
        Nombre: i.nombre, Categoría: i.categoria_nombre || '', Cantidad: i.cantidad,
        Estado: i.estado, Ubicación: i.ubicacion || ''
      }));
      this.exportarService.exportarExcel(datos, 'inventario', 'Inventario');
    });
  }

  imprimirInventario() {
    this.inventarioService.listar().subscribe(r => {
      if (!r.success) return;
      const filas = (r.data || []).map(i => [i.nombre, i.categoria_nombre || '—', i.cantidad, i.estado, i.ubicacion || '—']);
      this.exportarService.imprimirPdf(
        'Reporte de Inventario',
        ['Artículo', 'Categoría', 'Cantidad', 'Estado', 'Ubicación'],
        filas
      );
    });
  }

  // --- ASISTENCIA ---
  private nombreCurso(id: number | null): string {
    return this.cursos.find(c => c.id === id)?.nombre || '';
  }

  exportarAsistenciaExcel() {
    if (!this.cursoAsistencia) { alert('Selecciona un curso.'); return; }
    this.asistenciaService.historial(this.cursoAsistencia, this.desde, this.hasta).subscribe(r => {
      if (!r.success) return;
      const datos = (r.data || []).map((a: any) => ({
        Fecha: a.fecha, Alumno: `${a.nombres} ${a.apellidos}`, Estado: a.estado
      }));
      this.exportarService.exportarExcel(datos, 'asistencia', 'Asistencia');
    });
  }

  imprimirAsistencia() {
    if (!this.cursoAsistencia) { alert('Selecciona un curso.'); return; }
    this.asistenciaService.historial(this.cursoAsistencia, this.desde, this.hasta).subscribe(r => {
      if (!r.success) return;
      const filas = (r.data || []).map((a: any) => [a.fecha, `${a.nombres} ${a.apellidos}`, a.estado]);
      this.exportarService.imprimirPdf(
        'Reporte de Asistencia',
        ['Fecha', 'Alumno', 'Estado'],
        filas,
        `Curso: ${this.nombreCurso(this.cursoAsistencia)} | Del ${this.desde} al ${this.hasta}`
      );
    });
  }

  // --- NOTAS ---
  exportarNotasExcel() {
    if (!this.cursoNotas) { alert('Selecciona un curso.'); return; }
    this.notasService.obtenerPorCursoYPeriodo(this.cursoNotas, this.periodoNotas).subscribe(r => {
      if (!r.success) return;
      const datos = (r.data || []).map(n => ({
        Alumno: `${n.nombres} ${n.apellidos}`, Periodo: n.periodo, Nota: n.nota
      }));
      this.exportarService.exportarExcel(datos, 'notas', 'Notas');
    });
  }

  imprimirNotas() {
    if (!this.cursoNotas) { alert('Selecciona un curso.'); return; }
    this.notasService.obtenerPorCursoYPeriodo(this.cursoNotas, this.periodoNotas).subscribe(r => {
      if (!r.success) return;
      const filas = (r.data || []).map(n => [`${n.nombres} ${n.apellidos}`, n.nota]);
      this.exportarService.imprimirPdf(
        'Reporte de Notas',
        ['Alumno', 'Nota'],
        filas,
        `Curso: ${this.nombreCurso(this.cursoNotas)} | ${this.periodoNotas}`
      );
    });
  }
}
