import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Nota {
  id?: number;
  alumno_id: number;
  nombres?: string;
  apellidos?: string;
  curso_id: number;
  periodo: string;
  nota: number;
}

interface RespuestaApi<T> {
  success: boolean;
  data?: T;
  mensaje?: string;
}

@Injectable({ providedIn: 'root' })
export class NotasService {
  private http = inject(HttpClient);
  private readonly baseUrl = 'http://localhost:3000/api/notas';

  obtenerPorCursoYPeriodo(cursoId: number, periodo: string): Observable<RespuestaApi<Nota[]>> {
    return this.http.get<RespuestaApi<Nota[]>>(
      `${this.baseUrl}?curso_id=${cursoId}&periodo=${periodo}`
    );
  }

  guardar(cursoId: number, periodo: string, notas: Nota[]): Observable<RespuestaApi<any>> {
    return this.http.post<RespuestaApi<any>>(this.baseUrl, {
      curso_id: cursoId,
      periodo,
      notas
    });
  }
}
