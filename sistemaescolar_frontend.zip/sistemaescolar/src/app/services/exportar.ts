import { Injectable } from '@angular/core';
import * as XLSX from 'xlsx';

const NOMBRE_INSTITUCION = 'Complejo Educativo Cantón El Zunzal';

@Injectable({ providedIn: 'root' })
export class ExportarService {

  /** Exporta un arreglo de objetos a un archivo .xlsx descargable */
  exportarExcel(datos: any[], nombreArchivo: string, nombreHoja: string = 'Reporte') {
    if (!datos || datos.length === 0) {
      alert('No hay datos para exportar.');
      return;
    }
    const hoja = XLSX.utils.json_to_sheet(datos);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, nombreHoja);
    XLSX.writeFile(libro, `${nombreArchivo}.xlsx`);
  }

  /**
   * Abre una ventana nueva con una tabla formateada (con encabezado institucional)
   * y dispara el diálogo de impresión, que el usuario puede usar para "Guardar como PDF".
   */
  imprimirPdf(titulo: string, columnas: string[], filas: any[][], subtitulo?: string) {
    const ventana = window.open('', '_blank', 'width=900,height=700');
    if (!ventana) {
      alert('Tu navegador bloqueó la ventana emergente. Permite pop-ups para poder imprimir.');
      return;
    }

    const filasHtml = filas.map(fila =>
      `<tr>${fila.map(celda => `<td>${celda ?? ''}</td>`).join('')}</tr>`
    ).join('');

    const columnasHtml = columnas.map(c => `<th>${c}</th>`).join('');

    const fechaGeneracion = new Date().toLocaleString('es-SV');

    ventana.document.write(`
      <!DOCTYPE html>
      <html lang="es">
      <head>
        <meta charset="UTF-8" />
        <title>${titulo}</title>
        <style>
          body { font-family: Arial, Helvetica, sans-serif; margin: 24px; color: #222; }
          .encabezado { display: flex; align-items: center; gap: 16px; border-bottom: 3px solid #1e50a0; padding-bottom: 12px; margin-bottom: 16px; }
          .encabezado img { width: 64px; height: 64px; object-fit: contain; }
          .encabezado h1 { font-size: 18px; margin: 0; color: #1e50a0; }
          .encabezado p { margin: 2px 0 0 0; font-size: 13px; color: #555; }
          h2.titulo-reporte { font-size: 16px; margin: 12px 0 4px 0; }
          p.subtitulo { font-size: 13px; color: #555; margin: 0 0 12px 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 8px; }
          th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 12px; text-align: left; }
          th { background-color: #1e50a0; color: white; }
          tr:nth-child(even) { background-color: #f4f6fb; }
          .pie { margin-top: 24px; font-size: 11px; color: #888; text-align: right; }
          @media print {
            .no-imprimir { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="encabezado">
          <img src="${window.location.origin}/assets/icon/logo.png" alt="Logo" />
          <div>
            <h1>${NOMBRE_INSTITUCION}</h1>
            <p>Sistema de Gestión Escolar</p>
          </div>
        </div>

        <h2 class="titulo-reporte">${titulo}</h2>
        ${subtitulo ? `<p class="subtitulo">${subtitulo}</p>` : ''}

        <table>
          <thead><tr>${columnasHtml}</tr></thead>
          <tbody>${filasHtml}</tbody>
        </table>

        <div class="pie">Generado el ${fechaGeneracion}</div>

        <script>
          window.onload = function() {
            window.print();
          };
        </script>
      </body>
      </html>
    `);
    ventana.document.close();
  }
}
